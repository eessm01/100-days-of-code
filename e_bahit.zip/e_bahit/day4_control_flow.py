#!/usr/bin/env python3

my_list = ['Juan', 'Antonio', 'Pedro', 'Ana']

for element in my_list:
    print(element)

my_tuple = ('rosa', 'verde', 'celeste', 'amarillo')

for color in my_tuple:
    print(color)

for year in range(2001,2013):
    print('Informes de', year)
