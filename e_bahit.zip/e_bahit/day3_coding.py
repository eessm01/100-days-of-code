#!/usr/bin/env Python
#-*- coding: latin-1 -*-

""" En versiones anteriores a Python 3.0, la especificación de caracteres
    a emplearse (cuando ésta no es ASCII), resulta obligatoria.
    A partir de la versión 3.0, esta declaración es opcional.

    see http://python.org/dev/peps/pep-0263/ for details
"""

variable = "En el ��gara encontr� un �and�"
