#!/usr/bin/env python2
#-*- coding: utf-8 -*-
""" Día 1. página 5-7 y 9-11 de Introduccion al Lenguaje de programación Python
    #!/usr/bin/env python - Intérprete de python (versión por defecto del
    sistema)
    #!/usr/bin/env python2 - Fuerza a utilizar el intérprete de Python 2.x
    #!/usr/bin/env python3 - Fuerza a utilizar el intérprete de Python 3.x
    #!/usr/bin/env bash - Intérprete de GNU Bash

    En mac, después de habilitar el root, se puede poner en la siguiente ruta
    /usr/local/bin/
    para hacer del programa hello, un comando.
"""

print('Hola mundo!')
